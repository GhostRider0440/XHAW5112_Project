  import React,{ useState } from 'react';

import { View, Text, TextInput, Button, StyleSheet,TouchableOpacity,Alert } from 'react-native';

 


 

const ContactPage = ({ navigation }) => {

  const [NameInput, setNameInput] = useState('');
  const [EmailInput, setEmailInput] = useState('');
  const [PhoneInput, setPhoneInput] = useState('');
  const [AddressInput, setAddressInput] = useState('');
  const [MessageInput, setMessageInput] = useState('');

  const handleSubmit = () => {
    if (NameInput.trim() === '') {
      Alert.alert("Name input is empty");
    }

    if (EmailInput.trim() === '') {
      Alert.alert("Email input is empty");
    }

    if (PhoneInput.trim() === '') {
      Alert.alert("Phone number input is empty");
    }

    if (AddressInput.trim() === '') {
      Alert.alert("Address input is empty");
    }

    if (MessageInput.trim() === '') {
      Alert.alert("Please enter your message");
    } else {
      Alert.alert("Your message has been sent");
    }
  };

  

 

  return (

    <View style={styles.container}>

      <Text style={styles.header}>Contact Us</Text>

     

      <TextInput

        value={NameInput}

        style={styles.input}

        placeholder="Name"

        placeholderTextColor="black"

      />

      <TextInput

        value={EmailInput}

        style={styles.input}

        placeholder="Email"

        placeholderTextColor="black"

      />

      <TextInput

        value={PhoneInput}

        style={styles.input}

        placeholder="Phone Number"

        placeholderTextColor="black"

        keyboardType="phone-pad"

      />

      <TextInput

        value={AddressInput}

        style={styles.input}

        placeholder="Physical Address"

        placeholderTextColor="black"

      />

      <TextInput

        value={MessageInput}

        style={styles.textarea}

        placeholder="Message"

        multiline={true}

        numberOfLines={2}

        placeholderTextColor="black"

      />



      <TouchableOpacity style={styles.SubmitButton} onPress={handleSubmit}>
        <Text style={styles.SubmitButtonTxt}> Submit </Text>
      </TouchableOpacity>

    </View>

  );

};

 


 

const styles = StyleSheet.create({

  container: {

    flex: 1,

    padding: 25,

    backgroundColor: '#d6f7e2',

  },

  header: {

    fontSize: 30,

    fontWeight: 'bold',

    marginBottom: 20,

    textAlign: 'center',

    color: 'black',

  },

  input: {

    height: 40,

    borderColor: 'white',

    borderWidth: 3,

    marginBottom: 15,

    paddingLeft: 10,

    backgroundColor: 'white',

    color: 'black',

  },

  textarea: {

    height: 100,

    borderColor: 'black',

    borderWidth: 1,

    marginBottom: 15,

    paddingLeft: 10,

    backgroundColor: 'white',

    color: 'black',

  },

  SubmitButton:{
    backgroundColor:'#426B1F',
    borderRadius:10,
    width:100,
    height:50,
    top:50,
    left:120,
  },
  SubmitButtonTxt:{
    color:'white',
    top:15,
    left:20,
  },

});

 

export default ContactPage;