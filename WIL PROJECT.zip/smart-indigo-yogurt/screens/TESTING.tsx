import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';

const TESTING = () => {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
      <Text style={styles.headerText}>Welcome to Tradesman Academy</Text>
      </View>

      <View style={styles.content}>
     <Text style={styles.welcomeText}>Welcome to Your Learning Journey</Text>
      <Text style={styles.subtitle}>Explore a wide range of courses to enhance your skills and knowledge.</Text>

        <View style={styles.featureContainer}>
      <View style={styles.feature}>
        <Text style={styles.featureTitle}>Expert Instructors</Text>
        <Text style={styles.featureDescription}>Learn from industry experts with years of experience.</Text>
          </View>
          <View style={styles.feature}>
         <Text style={styles.featureTitle}>Interactive Content</Text>
        <Text style={styles.featureDescription}>Engage with interactive and engaging course materials.</Text>
         </View>
         <View style={styles.feature}>
         <Text style={styles.featureTitle}>Flexible Learning</Text>
      <Text style={styles.featureDescription}>Study at your own pace, anytime, anywhere.</Text>
      </View>
        </View>

        <TouchableOpacity style={styles.getStartedButton}>
          <Text style={styles.getStartedButtonText}>Get Started</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  header: {
    backgroundColor: '#426B1F',
    paddingVertical: 20,
    alignItems: 'center',
  },
  headerText: {
    color: 'white',
    fontSize: 24,
    fontWeight: 'bold',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  welcomeText: {
    fontSize: 24,
    color: '#426B1F',
    fontWeight: 'bold',
  },
  subtitle: {
    fontSize: 16,
    color: '#426B1F',
    marginVertical: 10,
  },
  featureContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  feature: {
    flex: 1,
    backgroundColor: '#F0F0F0',
    padding: 20,
    borderRadius: 10,
    marginHorizontal: 5,
  },
  featureTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#426B1F',
  },
  featureDescription: {
    fontSize: 14,
    color: '#426B1F',
    marginTop: 5,
  },
  getStartedButton: {
    backgroundColor: '#426B1F',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 30,
  },
  getStartedButtonText: {
    fontSize: 20,
    color: 'white',
    fontWeight: 'bold',
  },
});

export default TESTING;