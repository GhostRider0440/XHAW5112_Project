import * as React from 'react';
import { Button, View, Text,StyleSheet,SafeAreaView,TouchableOpacity,Image,ScrollView,TextInput } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import { useRoute } from '@react-navigation/native';



const Cart = () => {

  const PriceArray: any[] = [];

  let price = 0;
  let vat = 0;
  let TotalPrice = 0;

  const { params } = useRoute(); 

  let CoursePriceValue = params?.CoursePriceValue;

  PriceArray.push(parseInt(CoursePriceValue))
  price = PriceArray.reduce((accumulator, currentValue) =>      accumulator + currentValue, 0);

  vat = (price*0.15)
  TotalPrice = vat+price

  return (  
    <SafeAreaView style={styles.container}>
      <View style={styles.NavigationContainer}>
<Image style={styles.logo} source={require('./gallary/20230924_132752.png')}/>
     
      <TouchableOpacity style={styles.topbtn1} >
        <Text style={styles.topbtntxt1} >kitty:{CoursePriceValue}</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.topbtn2} onPress={() => navigation.navigate('Learn')}>
        <Text style={styles.topbtntxt2} >Learn</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.topbtn3} >
        <Text style={styles.topbtntxt3} >My Profile</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.topbtn4} >
        <Text style={styles.topbtntxt3} >My Profile</Text>
      </TouchableOpacity>


      <View>

      </View>


      <View style={styles.SummaryView}>
        <Text style={styles.SummaryTitle}>Order Summary</Text>
        <Text style={styles.SummarySubtotal}>Subtotal</Text>
        <Text style={styles.SummaryTax}>Tax</Text>
        <Text style={styles.SummaryTotal}>Total</Text>
      
        <View style={styles.SummaryViewPriceBox}>
          <Text style={styles.SummaryTotal}>{price}</Text>
          <Text style={styles.SummaryTotal}>{vat}</Text>
          <Text style={styles.SummaryTotal}>{TotalPrice}</Text>
        </View>

      </View>

      <TouchableOpacity style={styles.ContinueButton}>
       <Text style={styles.ContinueButtonTxt}>Continue to payment</Text>
       <Image style={styles.contiuelogo} source={require('./gallary/icons/arrow.png')}/>
      </TouchableOpacity>
      
      </View>

      <View style={styles.scrollbarcontainer}>  
        <ScrollView style={styles.scrollbar}>
          <View style={styles.coursecontainer}>
            <Text> Course 1</Text>
            <TextInput
              style={styles.input}
              value={"e"}
            />
             <Image style={styles.pencilicon} source={require('./gallary/pencil.png')}/>
             <Text style={styles.coursepricetxt}> R600</Text>
          </View>

          <View style={styles.coursecontainer}>
            <Text> Course 1</Text>
            <TextInput
              style={styles.input}
              value={"e"}
            />
             <Image style={styles.pencilicon} source={require('./gallary/pencil.png')}/>
             <Text style={styles.coursepricetxt}> R600</Text>
          </View>

          <View style={styles.coursecontainer}>
            <Text> Course 1</Text>
            <TextInput
              style={styles.input}
              value={"e"}
            />
             <Image style={styles.pencilicon} source={require('./gallary/pencil.png')}/>
             <Text style={styles.coursepricetxt}> R600</Text>
          </View>

          <View style={styles.coursecontainer}>
            <Text> Course 1</Text>
            <TextInput
              style={styles.input}
              value={"e"}
            />
             <Image style={styles.pencilicon} source={require('./gallary/pencil.png')}/>
             <Text style={styles.coursepricetxt}> R600</Text>
          </View>

          <View style={styles.coursecontainer}>
            <Text> Course 1</Text>
            <TextInput
              style={styles.input}
              value={"e"}
            />
             <Image style={styles.pencilicon} source={require('./gallary/pencil.png')}/>
             <Text style={styles.coursepricetxt}> R600</Text>
          </View>

          <View style={styles.coursecontainer}>
            <Text> Course 1</Text>
            <TextInput
              style={styles.input}
              value={"e"}
            />
             <Image style={styles.pencilicon} source={require('./gallary/pencil.png')}/>
             <Text style={styles.coursepricetxt}> R600</Text>
          </View>

        </ScrollView>
      
      </View>    
    </SafeAreaView>
  );
}










export default Cart;


const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  NavigationContainer:{
    position:"absolute",
    left:-10,
    top:1,
  },
  logo:{
    width:70,
    height:70, 
  },
// Navigation Buttons //
  topbtn1:{
    width:70,
    height:50,
    left:80,
    top:-60,
    textAlign:'center',
  },
  topbtn2:{
    width:70,
    height:50,
    left:150,
    top:-110,
    textAlign:'center',
  },
  topbtn3:{
    width:70,
    height:50,
    left:220,
    top:-160,
    textAlign:'center',
  },
  topbtn4:{
    backgroundColor:"#426B1F",
    width:95,
    height:50,
    left:300,
    top:-210,
    textAlign:'center',
  },
// Navigation Buttons //

  topbtntxt1:{
  fontWeight: "bold",
  fontSize:15,
  },
  topbtntxt2:{
    fontWeight: "bold",
    fontSize:20,
  },
  topbtntxt3:{
    fontWeight: "bold",
    fontSize:20,
  },

// Summary View content //
SummaryView:{
  position:"absolute",
  backgroundColor:"#e3e3e3",
  height:295,
  width:400,
  top:90,
  left:10,
},
SummaryTitle:{
  fontSize:30,
  margin:3,
},
SummarySubtotal:{
  fontSize:25,
  margin:3,
},
SummaryTax:{
  fontSize:25,
  margin:3,
},
SummaryTotal:{
  fontSize:25,
    margin:3,
},

SummaryViewPriceBox:{
  top:-117,
  left:280,
},
ContinueButton:{
    backgroundColor:"#426B1F",
    borderRadius:10,
    height:70,
    width:380,
    top:41,
    left:10,
},
ContinueButtonTxt:{
  fontSize:30,
  top:13,
  color:"white",
},
contiuelogo:{
  height:80,
  width:80,
  left:293,
  top:-45,
},

// Summary View content //


// scroll section //
scrollbarcontainer:{
  position:"absolute",
  top:400,  
  height:300,
  width:390,
},
coursecontainer:{
  backgroundColor:"#cccccc",
  height:70,
  borderRadius:15,
  margin:5,
},
input:{
  backgroundColor:"white",
  width:100,
  height:35,
  borderRadius:20,
},
pencilicon:{
  top:-32,
  left:105,
  width:25,
  height:25,
},
coursepricetxt:{
  fontSize:30,
  top:-68,
  left:270,
}

// scroll section //

});
