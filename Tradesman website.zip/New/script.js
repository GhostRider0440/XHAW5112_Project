document.addEventListener('DOMContentLoaded', () => {
    const cartItems = [];
    const cartTotal = document.getElementById('cart-total');
    const cartDiscount = document.getElementById('cart-discount');
    const cartList = document.getElementById('cart-items');
    const viewCartLink = document.getElementById('view-cart');

    const updateCart = () => {
        let total = 0;
        cartList.innerHTML = '';
        cartItems.forEach((item) => {
            const listItem = document.createElement('li');
            listItem.innerHTML = `
                ${item.name} - R${item.price.toFixed(2)}
                <button class="remove-item" data-index="${cartItems.indexOf(item)}">Remove</button>
            `;
            cartList.appendChild(listItem);
            total += item.price;
        });

        let discount = 0;

        // Apply discounts based on the number of items
        if (cartItems.length >= 2 && cartItems.length < 3) {
            discount = 5;
            total *= 0.95; // 5% discount for two items
        } else if (cartItems.length >= 3 && cartItems.length < 4) {
            discount = 10;
            total *= 0.90; // 10% discount for three items
        } else if (cartItems.length >= 4) {
            discount = 15;
            total *= 0.85; // 15% discount for more than three items
        }

        // Calculate VAT (15% of the total) and add it to the total
        const vat = total * 0.15;
        total += vat;

        cartTotal.textContent = `Total (including 15% VAT): R${total.toFixed(2)}`;
        cartDiscount.textContent = `Discount: ${discount}%`;
    };

    const addToCart = (price, name) => {
        cartItems.push({ price, name });
        updateCart();
    };

    document.querySelectorAll('.add-to-cart').forEach((button, index) => {
        button.addEventListener('click', () => {
            const price = parseFloat(button.getAttribute('data-price'));
            const name = document.querySelectorAll('.product h2')[index].textContent;
            addToCart(price, name);
        });
    });

    document.addEventListener('click', (event) => {
        if (event.target.classList.contains('remove-item')) {
            const index = parseInt(event.target.getAttribute('data-index'));
            cartItems.splice(index, 1);
            updateCart();
        }
    });

    viewCartLink.addEventListener('click', () => {
        document.querySelector('.cart').classList.toggle('open');
    });
});
